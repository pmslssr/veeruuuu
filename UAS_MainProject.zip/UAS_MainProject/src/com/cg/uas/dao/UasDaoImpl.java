package com.cg.uas.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.beans.ProgramsScheduledBean;




@Repository
@Transactional
public class UasDaoImpl implements IUasDao {


	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public LoginBean login(String username, String password) {
		LoginBean bean = entityManager.find(LoginBean.class,username);
		//bean.setRole("mac");bean.setPassword(password);bean.setUsername(username);;
		return bean;
	}

	@Override
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean) {
		entityManager.persist(bean);
		ProgramsOfferedBean bean1=entityManager.find(ProgramsOfferedBean.class, bean.getProgramName());
		entityManager.flush();
		return bean1;
	}

	@Override
	public List<ProgramsOfferedBean> viewAllProgramsOffered() {
		TypedQuery<ProgramsOfferedBean> query=entityManager.createQuery("FROM ProgramsOfferedBean",ProgramsOfferedBean.class);
		if(query.getResultList()!=null)
			return query.getResultList();
		else{
			List<ProgramsOfferedBean> list=new ArrayList<ProgramsOfferedBean>();
			return list;
		}
	}

	@Override
	public boolean deleteProgramsOffered(String programName) {
		boolean flag= false;
		ProgramsOfferedBean bean = entityManager.find(ProgramsOfferedBean.class,programName);
		if(bean!=null){
			entityManager.remove(bean);
			
		flag = true;
		}
		else{
			flag = false;
		}
		return flag;
	}

	@Override
	public ProgramsOfferedBean findByName(String programName) {
		ProgramsOfferedBean bean1=entityManager.find(ProgramsOfferedBean.class, programName);
		return bean1;
	}

	@Override
	public int modifyProgram(ProgramsOfferedBean bean) {
		
		Query query=entityManager.createQuery("update ProgramsOfferedBean set description=?,applicantEligibility=?,duration=?,degreeCertificate=? where programName=?");
		query.setParameter(1, bean.getDescription());
		query.setParameter(2, bean.getApplicantEligibility());
		query.setParameter(3, bean.getDuration());
		query.setParameter(4, bean.getDegreeCertificate());
		query.setParameter(5, bean.getProgramName());
		int count= query.executeUpdate();
		return count;
	}

	@Override
	public ProgramsScheduledBean addScheduledPrograms(ProgramsScheduledBean bean) {
		entityManager.persist(bean);
		ProgramsScheduledBean bean1=entityManager.find(ProgramsScheduledBean.class, bean.getScheduledProgramId());
		entityManager.flush();
		return bean1;
	}

	@Override
	public List<ProgramsScheduledBean> viewAllProgramsScheduled() {
		TypedQuery<ProgramsScheduledBean> query=entityManager.createQuery("FROM ProgramsScheduledBean",ProgramsScheduledBean.class);
		if(query.getResultList()!=null)
			return query.getResultList();
		else{
			List<ProgramsScheduledBean> list=new ArrayList<ProgramsScheduledBean>();
			return list;
		}
	}

	@Override
	public boolean deleteProgramsScheduled(int id) {
		boolean flag= false;
		ProgramsScheduledBean bean = entityManager.find(ProgramsScheduledBean.class,id);
		if(bean!=null){
			entityManager.remove(bean);
			
		flag = true;
		}
		else{
			flag = false;
		}
		return flag;
	}

	@Override
	public List<ProgramsScheduledBean> viewCommenceTime(ProgramsScheduledBean bean) {
		TypedQuery<ProgramsScheduledBean> query=entityManager.createQuery("FROM ProgramsScheduledBean where startDate>=? and endDate<=?",ProgramsScheduledBean.class);
		query.setParameter(1, bean.getStartDate());
		query.setParameter(2, bean.getEndDate());
		
		
		if(query.getResultList()!=null)
			return query.getResultList();
		else{
			List<ProgramsScheduledBean> list=new ArrayList<ProgramsScheduledBean>();
			return list;
		}
	}
	
	
	@Override
	public List<ProgramsScheduledBean> viewCourse() {
		TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("SELECT d FROM ProgramsScheduledBean d", ProgramsScheduledBean.class);
		return query.getResultList();
	}

	@Override
	public ApplicationBean addApplicant(ApplicationBean application) {
		entityManager.persist(application);
		entityManager.flush();
		return application;
	}

	@Override
	public ApplicationBean viewStatus(int id) {
		return entityManager.find(ApplicationBean.class, id);
	}

	@Override
	public List<ApplicationBean> getAllApplicants(String scheduledProgramID) {
		TypedQuery<ApplicationBean> query=entityManager.createQuery("FROM ApplicationBean where scheduledProgramId=?",ApplicationBean.class);
		int pid=Integer.parseInt(scheduledProgramID);
		query.setParameter(1,pid );
		return query.getResultList();
	}

	@Override
	public String getStatus(String applicantId) {
		 int applicationId=Integer.parseInt(applicantId);
		ApplicationBean bean= entityManager.find(ApplicationBean.class,applicationId);
		return bean.getStatus();
	}

	@Override
	public String changeStatus(String status,String applicationId) {
		ApplicationBean bean=new ApplicationBean();
		Query query=entityManager.createQuery("update ApplicationBean set status=? where applicationId=? ");
		query.setParameter(1, status);
		query.setParameter(2, Integer.parseInt(applicationId));
		int count=query.executeUpdate();
		if(count>0){
			bean=entityManager.find(ApplicationBean.class, Integer.parseInt(applicationId));
					return bean.getStatus();
		}
		else
			return null;
		
	}

/*	@Override
	public ApplicationBean updatedoi(int applicationId, Date dateOfInterview) {
		ApplicationBean bean=new ApplicationBean();
		Query query=entityManager.createQuery("update ApplicationBean set dateOfInterview=? where applicationId=? ");
		query.setParameter(1, dateOfInterview);
		query.setParameter(2, applicationId);
		int count=query.executeUpdate();
		if(count>0){
			bean=entityManager.find(ApplicationBean.class, applicationId);
			return bean;		
		}
		else
			return null;
	}*/


	}


