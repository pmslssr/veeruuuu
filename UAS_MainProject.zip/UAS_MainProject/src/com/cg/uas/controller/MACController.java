package com.cg.uas.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.service.IUasService;


@Controller
@RequestMapping("/*.mac")
public class MACController {

	@Autowired
	private IUasService service;

	public IUasService getService() {
		return service;
	}

	public void setService(IUasService service) {
		this.service = service;
	}
	
	@RequestMapping("/view")
	public ModelAndView viewApplicantsByProgram(@RequestParam("scheduledProgramId") String scheduledProgramId) {
		ModelAndView mv=new ModelAndView();
		/*List<String> statusList=new ArrayList<String>();
		statusList.add("Accepted");
		statusList.add("Rejected");*/
		List<ApplicationBean> list= service.getAllApplicants(scheduledProgramId);
		if (!list.isEmpty()){
			mv.addObject("list", list);
			mv.addObject("flag", 1);
			mv.setViewName("macPage");
			//mv.addObject("statusList", statusList);
		}
		else {
			mv.addObject("msg", "No Applicant is Registered for this Program");
			mv.setViewName("macPage");
		}
		
	return mv;	
	}
	
	@RequestMapping("/status")
	public ModelAndView viewStatus(@RequestParam("applicationId") String applicantId) {
		ModelAndView mv=new ModelAndView();
		
		String status=service.getStatus(applicantId);
		mv.addObject("status", status);
		if(status.equals("Waiting")){
			mv.addObject("flag", 6);
			mv.addObject("applicationId", applicantId);
			mv.addObject("accepted", "accepted");
			mv.addObject("rejected", "rejected");
			mv.setViewName("changeStatus");
		}
		else
		{
			mv.addObject("flag", 5);
			mv.addObject("msg", "Status Cannot be Changed");
			mv.setViewName("changeStatus");
		}
			
	return mv;
}
	

	@RequestMapping("/changeStatus")
	public ModelAndView changeStatus(@RequestParam("status") String status,@RequestParam("applicationId") String applicantId) {
		ModelAndView mv=new ModelAndView();
		
			String newStatus=service.changeStatus(status,applicantId);
		if(newStatus.equals("rejected")){
			mv.addObject("applicationId", applicantId);
			mv.addObject("flag", 5);
			mv.addObject("msg","Application has been Rejected");
			mv.setViewName("changeStatus");
			}
		else{
			
			mv.addObject("applicationId", applicantId);
			mv.addObject("flag", 5);
			mv.addObject("msg", "Application has been Accepted");
			mv.setViewName("changeStatus");
		
			}
	return mv;
}
	
/*	@RequestMapping("/update")
	public ModelAndView changeStatus(@ModelAttribute("bean") @Valid ApplicationBean bean, BindingResult result) {
		ModelAndView mv=new ModelAndView();
		
		ApplicationBean bean1=service.updatedoi(bean.getApplicationId());
		if(bean1==null)
		{
			mv.addObject("msg", "Updation Failed");
			mv.setViewName("changeStatus");
		}
		else
		{
			mv.addObject("flag", 8);
			//mv.addObject("doi", bean.getDateOfInterview());
			mv.addObject("msg", "Date Of Interview has been set on: ");
			mv.setViewName("changeStatus");
		}
		return mv;
		
}*/
}
