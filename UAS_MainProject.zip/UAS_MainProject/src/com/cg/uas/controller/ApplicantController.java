package com.cg.uas.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.service.IUasService;

@Controller
@RequestMapping("/*.app")
public class ApplicantController {

	@Autowired
	private IUasService service;

	public IUasService getService() {
		return service;
	}

	public void setService(IUasService service) {
		this.service = service;
	}
	
	@RequestMapping("/viewCourse")
	public ModelAndView showabout() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("isFirst",4);
		List<ProgramsScheduledBean> list=service.viewCourse();
		if(list.isEmpty()){
			String msg = "There are no Courses";
			mv.setViewName("a");
			mv.addObject("msg", msg);
		}
		else
		{	

			mv.setViewName("viewCourse");
			mv.addObject("list", list);
			
		}
		
	return mv;	
	}
	
	@RequestMapping("/apply")
	public ModelAndView apply(@RequestParam("scheduledProgramId") int id) {
		
		ApplicationBean applicant=new ApplicationBean();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("viewCourse");
		mv.addObject("applicant", applicant);
		mv.addObject("scheduledProgramId",id);
		mv.addObject("sample", true);
		
		mv.addObject("isFirst", 4);
		List<ProgramsScheduledBean> list = service.viewCourse();
		if (list.isEmpty()) {
			String msg = "There are no Courses";
			
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewCourse");
			mv.addObject("list", list);
			
			
		}
	return mv;
		
	}
	
	@RequestMapping("/applicantSubmit")
	public ModelAndView applicantSubmit(
			@ModelAttribute("applicant") @Valid ApplicationBean applicant,
			BindingResult result) {

		ModelAndView mv = new ModelAndView();
		
		/*if(!result.hasErrors()){*/
			ApplicationBean applicant1 = service.addApplicant(applicant);
		if (applicant1 != null) {
			mv.addObject("flag1", true);
			mv.addObject("msg1", "Your application has been registered successfully");
			mv.addObject("msg", "Your applicant Id is: ");
			
			List<ProgramsScheduledBean> list = service.viewCourse();
			if (list.isEmpty()) {
				String msg = "There are no Courses";
				
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("viewCourse");
				mv.addObject("list", list);
				
				mv.addObject("applicant1", applicant1);
			}
		} else {
			mv.addObject("msg", "Failed to Add");
		}
		mv.setViewName("viewCourse");
		
		/*
			return new ModelAndView("viewCourse", "applicant", applicant);
		}*/
		return mv;

	}
	
	@RequestMapping("/checkStatus")
	public ModelAndView checkStatus() {
		ModelAndView mv=new ModelAndView();
		ApplicationBean applicant=new ApplicationBean();
		mv.addObject("applicant", applicant);
		mv.addObject("isFirst",5);
		mv.setViewName("checkStatus");
	return mv;
		
	}
	
	@RequestMapping("/displayStatus")
	public ModelAndView displayStatus(@ModelAttribute("applicant") ApplicationBean applicant) {
		
		ModelAndView mv = new ModelAndView();

		ApplicationBean applicant2=new ApplicationBean();
		applicant2=service.viewStatus(applicant.getApplicationId());
		
		if (applicant2 != null) {
			
			mv.setViewName("checkStatus");
			mv.addObject("applicant", applicant2);
			mv.addObject("flag2", true);
			/*if(applicant2.getDateOfInterview()==null)
			mv.addObject("msg1", "Not Scheduled");*/
		} else {
			
			String msg = "Enter a Valid Id!!";
			mv.setViewName("checkStatus");
			mv.addObject("msg", msg);
		}
		return mv;
	}
}
	